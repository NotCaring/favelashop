import { Product } from '../types/product';

export const products: Product[] = [
  {
    id: 1,
    name: "Painel Android",
    description: "Painel Android Permanente com funções avançadas para dominar o jogo. Tecnologia de ponta para máxima performance.",
    price: 40.00,
    originalPrice: 59.99,
    category: "painel",
    features: [
      "Aimlock Preciso",
      "NeckLock Automático", 
      "Puxar Inimigos",
      "Anti-Ban Garantido",
      "Suporte 24/7",
      "Atualizações Vitalícias"
    ]
  },
  {
    id: 2,
    name: "Aimbot+ Holograma Android",
    description: "Aimbot Holograma Permanente com tecnologia invisível. O mais avançado sistema de mira automática do mercado.",
    price: 20.00,
    originalPrice: 79.99,
    category: "aimbot",
    features: [
      "Holograma Invisível",
      "Mira Automática",
      "Detecção Zero",
      "Configuração Fácil",
      "Compatível com Todos Dispositivos",
      "Garantia Vitalícia"
    ]
  },
  {
    id: 3,
    name: "Painel Avançado Android",
    description: "Controle total com opções premium. O kit mais completo para gamers profissionais que buscam dominação absoluta.",
    price: 50.00,
    originalPrice: 89.99,
    category: "avancado",
    features: [
      "Aimbot Legit",
      "Box ESP",
      "Neck Automático",
      "UMP Puxar",
      "Menu Customizável",
      "Proteção Avançada"
    ]
  }
];