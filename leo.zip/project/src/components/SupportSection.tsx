import React from 'react';
import { motion } from 'framer-motion';
import { MessageCircle, Headphones, Users, Clock } from 'lucide-react';

const SupportSection: React.FC = () => {
  return (
    <motion.div 
      className="bg-gradient-to-br from-red-950/80 to-black/90 backdrop-blur-sm border-2 border-red-500/50 rounded-2xl p-8 mt-16 text-center shadow-2xl relative overflow-hidden"
      whileHover={{ scale: 1.01 }}
      transition={{ duration: 0.3 }}
    >
      {/* Animated background */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-red-500/5 via-transparent to-red-500/5"
        animate={{
          x: ['-100%', '100%', '-100%'],
        }}
        transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
      />

      <div className="relative z-10">
        <motion.div 
          className="flex items-center justify-center gap-3 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Headphones className="w-8 h-8 text-red-500" />
          </motion.div>
          <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-red-600">
            Suporte 24/7
          </h2>
          <motion.div
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Users className="w-8 h-8 text-red-500" />
          </motion.div>
        </motion.div>
        
        <motion.p 
          className="text-gray-300 text-xl mb-8 max-w-2xl mx-auto"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          Tem dúvidas ou precisa de ajuda? Nossa equipe especializada está sempre disponível para você!
        </motion.p>

        {/* Support features */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="bg-red-950/30 p-4 rounded-xl border border-red-500/20">
            <Clock className="w-6 h-6 text-green-400 mx-auto mb-2" />
            <h3 className="font-bold text-white mb-1">Resposta Rápida</h3>
            <p className="text-gray-400 text-sm">Atendimento em até 5 minutos</p>
          </div>
          <div className="bg-red-950/30 p-4 rounded-xl border border-red-500/20">
            <Users className="w-6 h-6 text-blue-400 mx-auto mb-2" />
            <h3 className="font-bold text-white mb-1">Equipe Especializada</h3>
            <p className="text-gray-400 text-sm">Experts em gaming e tecnologia</p>
          </div>
          <div className="bg-red-950/30 p-4 rounded-xl border border-red-500/20">
            <Headphones className="w-6 h-6 text-purple-400 mx-auto mb-2" />
            <h3 className="font-bold text-white mb-1">Suporte Completo</h3>
            <p className="text-gray-400 text-sm">Instalação e configuração</p>
          </div>
        </motion.div>
        
        {/* Contact buttons */}
        <motion.div 
          className="flex flex-col sm:flex-row gap-4 justify-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
        >
          <motion.a
            href="https://discord.gg/bfaX9WKZKu"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 px-8 rounded-xl transition-all duration-200 shadow-lg"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            <MessageCircle className="w-5 h-5" />
            Entrar no Discord
          </motion.a>
          
          <motion.a
            href="mailto:suporte@favelashop.com"
            className="inline-flex items-center gap-3 bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-4 px-8 rounded-xl transition-all duration-200 shadow-lg"
            whileHover={{ scale: 1.05, y: -2 }}
            whileTap={{ scale: 0.95 }}
          >
            <Headphones className="w-5 h-5" />
            Email Suporte
          </motion.a>
        </motion.div>
      </div>
    </motion.div>
  );
};

export default SupportSection;