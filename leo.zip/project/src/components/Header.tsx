import React from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Crown, Zap } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <motion.header 
      className="relative bg-gradient-to-r from-red-950 via-black to-red-950 border-b-4 border-red-500 py-8 px-5 overflow-hidden"
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, delay: 0.5 }}
    >
      {/* Animated background pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-red-500/20 to-transparent transform -skew-y-1"></div>
      </div>

      <div className="max-w-6xl mx-auto text-center relative z-10">
        <motion.div 
          className="flex items-center justify-center gap-4 mb-3"
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <motion.div
            animate={{ rotate: [0, 10, -10, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            <Gamepad2 className="w-10 h-10 text-red-500" />
          </motion.div>
          
          <motion.h1 
            className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-red-500 to-red-600"
            animate={{ 
              backgroundPosition: ['0% 50%', '100% 50%', '0% 50%']
            }}
            transition={{ duration: 3, repeat: Infinity }}
            style={{ backgroundSize: '200% 200%' }}
          >
            Favela Shop
          </motion.h1>
          
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Crown className="w-10 h-10 text-yellow-400" />
          </motion.div>
        </motion.div>
        
        <motion.div
          className="flex items-center justify-center gap-2 text-red-300 text-lg md:text-xl"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          <Zap className="w-5 h-5 text-yellow-400" />
          <span className="font-semibold">Equipamentos e hacks para gamers profissionais</span>
          <Zap className="w-5 h-5 text-yellow-400" />
        </motion.div>

        {/* Animated underline */}
        <motion.div
          className="mt-4 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent mx-auto"
          initial={{ width: 0 }}
          animate={{ width: '60%' }}
          transition={{ duration: 1, delay: 1.2 }}
        />
      </div>
    </motion.header>
  );
};

export default Header;