import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, Star, Zap, Shield, Target, Gamepad2 } from 'lucide-react';
import CheckoutForm from './CheckoutForm';
import { Product } from '../types/product';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const [showCheckout, setShowCheckout] = useState(false);
  const [timeLeft, setTimeLeft] = useState(15 * 60);
  const [isHovered, setIsHovered] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft((prev) => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCheckoutSuccess = () => {
    setShowCheckout(false);
  };

  const getProductIcon = (category: string) => {
    switch (category) {
      case 'painel': return <Shield className="w-6 h-6" />;
      case 'aimbot': return <Target className="w-6 h-6" />;
      case 'avancado': return <Gamepad2 className="w-6 h-6" />;
      default: return <Zap className="w-6 h-6" />;
    }
  };

  return (
    <motion.div 
      className="relative bg-gradient-to-br from-red-950/80 via-black/90 to-red-900/80 backdrop-blur-sm border-2 border-red-500/50 rounded-2xl p-8 shadow-2xl overflow-hidden group"
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      whileHover={{ 
        scale: 1.02,
        boxShadow: '0 25px 50px -12px rgba(239, 68, 68, 0.4)'
      }}
      transition={{ duration: 0.3 }}
    >
      {/* Animated background gradient */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-red-500/10 via-transparent to-red-500/10"
        animate={{
          x: isHovered ? ['-100%', '100%'] : 0,
        }}
        transition={{ duration: 1.5, repeat: isHovered ? Infinity : 0 }}
      />

      {/* Glowing border effect */}
      <motion.div
        className="absolute inset-0 rounded-2xl"
        animate={{
          boxShadow: isHovered 
            ? ['0 0 20px rgba(239, 68, 68, 0.3)', '0 0 40px rgba(239, 68, 68, 0.6)', '0 0 20px rgba(239, 68, 68, 0.3)']
            : '0 0 0px rgba(239, 68, 68, 0)'
        }}
        transition={{ duration: 2, repeat: Infinity }}
      />

      <div className="relative z-10">
        {/* Timer and offer badge */}
        <div className="flex items-center justify-between mb-6">
          <motion.div 
            className="flex items-center gap-2 text-red-400 bg-red-950/50 px-4 py-2 rounded-full border border-red-500/30"
            animate={{ scale: timeLeft < 60 ? [1, 1.05, 1] : 1 }}
            transition={{ duration: 0.5, repeat: timeLeft < 60 ? Infinity : 0 }}
          >
            <Clock className="w-4 h-4" />
            <span className="font-bold">
              {timeLeft > 0 ? `Termina em ${formatTime(timeLeft)}` : 'Oferta encerrada'}
            </span>
          </motion.div>
          
          <motion.div 
            className="bg-gradient-to-r from-red-500 to-red-600 text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg"
            whileHover={{ scale: 1.05 }}
          >
            Oferta Exclusiva
          </motion.div>
        </div>
        
        {/* Product title with icon */}
        <motion.div className="flex items-center gap-3 mb-4">
          <motion.div
            className="text-red-500"
            animate={{ rotate: isHovered ? 360 : 0 }}
            transition={{ duration: 0.6 }}
          >
            {getProductIcon(product.category)}
          </motion.div>
          <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-2">
            {product.name}
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <Star className="w-6 h-6 text-yellow-400 fill-current" />
            </motion.div>
          </h2>
        </motion.div>
        
        {/* Description */}
        <p className="text-gray-300 mb-6 leading-relaxed text-lg">
          {product.description}
        </p>
        
        {/* Features list */}
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {product.features?.map((feature, index) => (
            <motion.div
              key={index}
              className="flex items-center gap-2 text-green-400 bg-green-950/20 px-3 py-2 rounded-lg border border-green-500/20"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.1 * index }}
            >
              <Zap className="w-4 h-4" />
              <span className="text-sm font-medium">{feature}</span>
            </motion.div>
          ))}
        </motion.div>
        
        {/* Pricing */}
        <div className="flex items-center gap-4 mb-8">
          <motion.span 
            className="text-3xl md:text-4xl font-black text-white"
            whileHover={{ scale: 1.05 }}
          >
            R$ {product.price.toFixed(2)}
          </motion.span>
          <span className="text-xl text-red-400 line-through">
            R$ {product.originalPrice.toFixed(2)}
          </span>
          <motion.span 
            className="bg-gradient-to-r from-green-500 to-green-600 text-white px-3 py-1 rounded-full text-sm font-bold shadow-lg"
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            {Math.round((1 - product.price / product.originalPrice) * 100)}% OFF
          </motion.span>
        </div>
        
        {/* Buy button */}
        <motion.button
          onClick={() => setShowCheckout(!showCheckout)}
          className="relative w-full bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white font-bold py-4 px-8 rounded-xl text-lg shadow-lg overflow-hidden group"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <motion.div
            className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent"
            animate={{
              x: isHovered ? ['-100%', '100%'] : '-100%',
            }}
            transition={{ duration: 0.6 }}
          />
          <span className="relative z-10 flex items-center justify-center gap-2">
            <Zap className="w-5 h-5" />
            Comprar Agora
          </span>
        </motion.button>
        
        {/* Checkout form */}
        <AnimatePresence>
          {showCheckout && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <CheckoutForm
                product={product}
                onSuccess={handleCheckoutSuccess}
                onCancel={() => setShowCheckout(false)}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
};

export default ProductCard;