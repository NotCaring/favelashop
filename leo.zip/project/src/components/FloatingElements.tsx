import React from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Target, Zap, Shield, Crown, Star } from 'lucide-react';

const FloatingElements: React.FC = () => {
  const elements = [
    { Icon: Gamepad2, color: 'text-red-400', delay: 0 },
    { Icon: Target, color: 'text-green-400', delay: 1 },
    { Icon: Zap, color: 'text-yellow-400', delay: 2 },
    { Icon: Shield, color: 'text-blue-400', delay: 3 },
    { Icon: Crown, color: 'text-purple-400', delay: 4 },
    { Icon: Star, color: 'text-pink-400', delay: 5 },
  ];

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {elements.map(({ Icon, color, delay }, index) => (
        <motion.div
          key={index}
          className={`absolute ${color} opacity-20`}
          initial={{ 
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            scale: 0,
            rotate: 0
          }}
          animate={{
            y: [null, -20, 20, -20],
            x: [null, 10, -10, 10],
            rotate: [0, 360],
            scale: [0.5, 1, 0.5]
          }}
          transition={{
            duration: 8 + Math.random() * 4,
            repeat: Infinity,
            delay: delay,
            ease: "easeInOut"
          }}
          style={{
            left: `${10 + (index * 15)}%`,
            top: `${10 + (index * 12)}%`
          }}
        >
          <Icon className="w-8 h-8" />
        </motion.div>
      ))}
    </div>
  );
};

export default FloatingElements;