import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { TrendingUp, User, MapPin } from 'lucide-react';

const ActivityMessage: React.FC = () => {
  const [currentMessage, setCurrentMessage] = useState(0);
  
  const messages = [
    { name: "João", product: "Painel Android", time: "2 min", location: "São Paulo" },
    { name: "Maria", product: "Aimbot Holograma", time: "5 min", location: "Rio de Janeiro" },
    { name: "Carlos", product: "Painel Avançado", time: "8 min", location: "Belo Horizonte" },
    { name: "Ana", product: "Painel Android", time: "12 min", location: "Salvador" },
    { name: "Pedro", product: "Aimbot Holograma", time: "15 min", location: "Brasília" }
  ];

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentMessage((prev) => (prev + 1) % messages.length);
    }, 4000);

    return () => clearInterval(interval);
  }, []);

  return (
    <motion.div 
      className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-20"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.6, delay: 2 }}
    >
      <AnimatePresence mode="wait">
        <motion.div
          key={currentMessage}
          className="bg-gradient-to-r from-red-900/90 to-red-800/90 backdrop-blur-sm border-2 border-red-500/50 rounded-2xl px-6 py-4 shadow-2xl max-w-sm"
          initial={{ opacity: 0, scale: 0.8, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: -20 }}
          transition={{ duration: 0.3 }}
          whileHover={{ scale: 1.05 }}
        >
          <div className="flex items-center gap-3">
            <motion.div
              animate={{ scale: [1, 1.2, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            >
              <TrendingUp className="w-5 h-5 text-green-400" />
            </motion.div>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 text-white font-bold text-sm">
                <User className="w-4 h-4 text-blue-400" />
                {messages[currentMessage].name}
                <span className="text-red-300">comprou</span>
              </div>
              <div className="text-red-200 text-xs">
                {messages[currentMessage].product}
              </div>
              <div className="flex items-center gap-2 text-gray-400 text-xs mt-1">
                <MapPin className="w-3 h-3" />
                {messages[currentMessage].location} • há {messages[currentMessage].time}
              </div>
            </div>

            <motion.div
              className="w-2 h-2 bg-green-400 rounded-full"
              animate={{ opacity: [1, 0.3, 1] }}
              transition={{ duration: 1, repeat: Infinity }}
            />
          </div>
        </motion.div>
      </AnimatePresence>
    </motion.div>
  );
};

export default ActivityMessage;