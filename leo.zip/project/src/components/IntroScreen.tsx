import React from 'react';
import { motion } from 'framer-motion';
import { Gamepad2, Zap, Target } from 'lucide-react';

const IntroScreen: React.FC = () => {
  return (
    <motion.div 
      className="fixed inset-0 bg-gradient-to-br from-red-950 via-black to-red-900 flex items-center justify-center z-50"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      transition={{ duration: 1, delay: 3 }}
    >
      <div className="text-center px-6 relative">
        {/* Animated background elements */}
        <motion.div
          className="absolute -top-20 -left-20 w-40 h-40 bg-red-500/20 rounded-full blur-3xl"
          animate={{ 
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        />
        <motion.div
          className="absolute -bottom-20 -right-20 w-32 h-32 bg-red-600/30 rounded-full blur-2xl"
          animate={{ 
            scale: [1.2, 1, 1.2],
            opacity: [0.4, 0.7, 0.4]
          }}
          transition={{ duration: 2.5, repeat: Infinity }}
        />

        {/* Main title with stagger animation */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.5 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-red-400 via-red-500 to-red-600 mb-4"
            animate={{ 
              textShadow: [
                '0 0 20px rgba(239, 68, 68, 0.5)',
                '0 0 40px rgba(239, 68, 68, 0.8)',
                '0 0 20px rgba(239, 68, 68, 0.5)'
              ]
            }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            Favela Shop
          </motion.h1>
        </motion.div>

        {/* Animated icons */}
        <motion.div 
          className="flex justify-center gap-8 mb-6"
          initial={{ opacity: 0, scale: 0 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          >
            <Gamepad2 className="w-8 h-8 text-red-400" />
          </motion.div>
          <motion.div
            animate={{ y: [-5, 5, -5] }}
            transition={{ duration: 1.5, repeat: Infinity }}
          >
            <Zap className="w-8 h-8 text-yellow-400" />
          </motion.div>
          <motion.div
            animate={{ scale: [1, 1.2, 1] }}
            transition={{ duration: 1, repeat: Infinity }}
          >
            <Target className="w-8 h-8 text-green-400" />
          </motion.div>
        </motion.div>

        {/* Subtitle */}
        <motion.p 
          className="text-red-300 text-xl md:text-2xl font-semibold"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1.5 }}
        >
          Bem-vindo ao futuro do gaming
        </motion.p>

        {/* Loading bar */}
        <motion.div 
          className="mt-8 w-64 h-1 bg-red-900 rounded-full mx-auto overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2 }}
        >
          <motion.div
            className="h-full bg-gradient-to-r from-red-500 to-red-400 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: 1.5, delay: 2 }}
          />
        </motion.div>
      </div>
    </motion.div>
  );
};

export default IntroScreen;