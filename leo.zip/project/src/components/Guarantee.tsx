import React from 'react';
import { motion } from 'framer-motion';
import { Shield, CheckCircle, Lock, Zap, Award } from 'lucide-react';

const Guarantee: React.FC = () => {
  const guarantees = [
    {
      icon: <Lock className="w-8 h-8" />,
      title: "Compra Segura",
      description: "Pagamento 100% protegido",
      color: "text-green-400"
    },
    {
      icon: <Zap className="w-8 h-8" />,
      title: "Entrega Instantânea",
      description: "Receba em até 5 minutos",
      color: "text-blue-400"
    },
    {
      icon: <Award className="w-8 h-8" />,
      title: "Suporte Vitalício",
      description: "Ajuda sempre disponível",
      color: "text-purple-400"
    }
  ];

  return (
    <div className="max-w-6xl mx-auto my-16 px-5">
      <motion.div 
        className="bg-gradient-to-br from-red-950/90 via-black/90 to-red-900/80 backdrop-blur-sm border-2 border-red-500/50 rounded-2xl p-10 text-center shadow-2xl relative overflow-hidden"
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        whileHover={{ scale: 1.01 }}
      >
        {/* Animated background elements */}
        <motion.div
          className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-red-500/10 to-transparent"
          animate={{
            x: ['-100%', '100%', '-100%'],
          }}
          transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
        />

        <div className="relative z-10">
          <motion.div 
            className="flex items-center justify-center gap-4 mb-8"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <Shield className="w-12 h-12 text-green-400" />
            </motion.div>
            <h2 className="text-4xl font-black text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-green-600">
              Garantia Total
            </h2>
            <motion.div
              animate={{ rotate: [360, 0] }}
              transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
            >
              <Shield className="w-12 h-12 text-green-400" />
            </motion.div>
          </motion.div>
          
          <motion.div 
            className="grid md:grid-cols-3 gap-8 mt-8"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            {guarantees.map((guarantee, index) => (
              <motion.div
                key={index}
                className="bg-red-950/30 p-6 rounded-xl border border-red-500/20 backdrop-blur-sm"
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 * index }}
                whileHover={{ 
                  scale: 1.05,
                  boxShadow: '0 10px 30px rgba(239, 68, 68, 0.2)'
                }}
              >
                <motion.div
                  className={`${guarantee.color} mb-4 flex justify-center`}
                  animate={{ y: [0, -5, 0] }}
                  transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                >
                  {guarantee.icon}
                </motion.div>
                <h3 className="font-bold text-white mb-2 text-lg">{guarantee.title}</h3>
                <p className="text-gray-300">{guarantee.description}</p>
              </motion.div>
            ))}
          </motion.div>

          {/* Trust badges */}
          <motion.div 
            className="flex items-center justify-center gap-6 mt-8 pt-6 border-t border-red-500/20"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
          >
            <div className="flex items-center gap-2 text-green-400">
              <CheckCircle className="w-5 h-5" />
              <span className="font-semibold">SSL Seguro</span>
            </div>
            <div className="flex items-center gap-2 text-blue-400">
              <CheckCircle className="w-5 h-5" />
              <span className="font-semibold">Dados Protegidos</span>
            </div>
            <div className="flex items-center gap-2 text-purple-400">
              <CheckCircle className="w-5 h-5" />
              <span className="font-semibold">Suporte 24h</span>
            </div>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};

export default Guarantee;