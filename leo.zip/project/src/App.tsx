import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import IntroScreen from './components/IntroScreen';
import Header from './components/Header';
import ProductCard from './components/ProductCard';
import SupportSection from './components/SupportSection';
import Guarantee from './components/Guarantee';
import ActivityMessage from './components/ActivityMessage';
import ParticleBackground from './components/ParticleBackground';
import FloatingElements from './components/FloatingElements';
import { products } from './data/products';

function App() {
  const [showIntro, setShowIntro] = useState(true);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowIntro(false);
      setIsLoaded(true);
    }, 4000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-red-950 to-black text-white overflow-x-hidden relative">
      <AnimatePresence>
        {showIntro && <IntroScreen />}
      </AnimatePresence>
      
      <ParticleBackground />
      <FloatingElements />
      
      <div className="relative z-10">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: isLoaded ? 1 : 0 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          <Header />
          
          <div className="max-w-6xl mx-auto px-5 py-12">
            <motion.div 
              className="space-y-12"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.8 }}
            >
              {products.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, x: index % 2 === 0 ? -100 : 100 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.6, delay: 1 + index * 0.2 }}
                >
                  <ProductCard product={product} />
                </motion.div>
              ))}
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.8 }}
            >
              <SupportSection />
            </motion.div>
          </div>
          
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6, delay: 2 }}
          >
            <Guarantee />
          </motion.div>
          
          <ActivityMessage />
        </motion.div>
      </div>
    </div>
  );
}

export default App;